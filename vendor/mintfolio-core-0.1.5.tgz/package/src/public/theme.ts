/** Theme authors depend on this contract, never on Core's routes or content readers. */
export * from '@mintfolio/theme-api';
