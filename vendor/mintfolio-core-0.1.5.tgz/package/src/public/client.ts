/** Optional browser behavior; importing a controller does not mount global UI. */
export * from '@mintfolio/theme-api/client';
export * from '../client/lifecycle.js';
export * from '../client/postList.js';
export * from '../client/protectedArticle.js';
export * from '../client/toc.js';
export * from '../client/lightbox.js';
export * from '../client/archive.js';
export * from '../client/code.js';
export * from '../client/navigation.js';
