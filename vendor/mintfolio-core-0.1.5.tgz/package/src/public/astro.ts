/** Renderer props and page semantics shared by every theme. */
export * from '@mintfolio/theme-api/astro';
